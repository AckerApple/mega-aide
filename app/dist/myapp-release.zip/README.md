## Downloads

Download the **entire** folder for your operating system and open the app file for your system.
